package cers2;

import org.openqa.selenium.support.PageFactory;

public class CadastroPage extends CadastroElementMap {
	
	public CadastroPage() {
		PageFactory.initElements(TestRule.getDriver(),this);
	}

	public void acessarMenuCadastrese() {
		// TODO Auto-generated method stub
		bt_login_register.click();
		bt_register.click();
		
	}

	public void preencherCamposObrigatorios() throws InterruptedException {
		// TODO Auto-generated method stub
		Thread.sleep(3000);
		campo_nome.sendKeys("Rubens Barrichello");
		campo_cpf.sendKeys("45588387600");
		campo_email.sendKeys("teste@teste.com.br");
		campo_senha.sendKeys("123456");
		campo_confSenha.sendKeys("123456");
		cookie.click();
		Thread.sleep(2000);
		check.click();
		
	}

	public void clicarBtMeCadastrar() {
		// TODO Auto-generated method stub		
		bt_meCadastrar.click();
	}

	public void verificarCadastro() throws InterruptedException {
		// TODO Auto-generated method stub
		Thread.sleep(2000);
		welcome.equals(welcome);
		
	}
	

	

}

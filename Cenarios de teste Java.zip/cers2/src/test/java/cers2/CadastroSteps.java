package cers2;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class CadastroSteps {

	@Given ("acessar o menu Login ou Cadastre se >> Cadastra se")
	public void acessarMenuCadastrese() {
		CadastroPage cadastroPage = new CadastroPage();
		cadastroPage.acessarMenuCadastrese();
		
	}
	
    @When ("na tela de cadastro preencher os campos obrigatorios")
    public void preencherCamposObrigatorios() throws InterruptedException {
    	CadastroPage cadastroPage = new CadastroPage();
		cadastroPage.preencherCamposObrigatorios();
    }
    
    @And ("na tela de cadastro clicar no botao Me cadastrar")
    public void clicarBtMeCadastrar() {
    	CadastroPage cadastroPage = new CadastroPage();
		cadastroPage.clicarBtMeCadastrar();
    }
    @Then ("o usuario eh cadastrado com sucesso")
    public void verificarCadastro() throws InterruptedException {
    	CadastroPage cadastroPage = new CadastroPage();
		cadastroPage.verificarCadastro();
    }
}

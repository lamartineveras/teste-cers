package cers2;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class CadastroElementMap {
	
	@FindBy(xpath = "//*[@id=\"dropdown-login-register-btn\"]")
	protected WebElement bt_login_register;
	
	@FindBy(xpath = "//*[@id=\"dropdown-register-btn\"]")
	protected WebElement bt_register;
	
	@FindBy(xpath = "//*[@id=\"name\"]")
	protected WebElement campo_nome;
	
	@FindBy(xpath = "//*[@id=\"cpf\"]")
	protected WebElement campo_cpf;
	
	@FindBy(xpath = "//*[@id=\"email\"]")
	protected WebElement campo_email;
	
	@FindBy(xpath = "//*[@id=\"password\"]")
	protected WebElement campo_senha;
	
	@FindBy(xpath = "//*[@id=\"newPassword\"]")
	protected WebElement campo_confSenha;
	
	@FindBy(xpath = "//*[@id=\"__next\"]/main/div/form/div[7]/div/label")
	protected WebElement check;
	
	@FindBy(xpath = "//*[@id=\"register-submit\"]")
	protected WebElement bt_meCadastrar;
	
	//protected WebElement welcome;
	@FindBy(xpath = "//*[@id=\"welcome\"]")
	protected WebElement welcome;
	
	@FindBy(xpath = "//*[@id=\"rcc-confirm-button\"]")
	protected WebElement cookie;

}

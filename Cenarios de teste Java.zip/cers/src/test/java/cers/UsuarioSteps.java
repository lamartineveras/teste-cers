package cers;

import org.junit.runner.RunWith;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.cucumber.junit.Cucumber;

@RunWith(Cucumber.class)
public class UsuarioSteps {
	/*@Given ("acessar a url da pagina")
	public void acessarUrl() {
		UsuarioPage usuarioPage = new UsuarioPage();
		usuarioPage.acessarUrl();
	}*/
	
    @Given ("acessar o menu Login ou Cadastre se >> Login")
    public void acessarMenuLogin() throws InterruptedException {
    	UsuarioPage usuarioPage = new UsuarioPage();
		usuarioPage.acessarMenuLogin();
    }
    
    @When ("na tela de login informar email e clicar em prosseguir")
    public void informarEmail() throws InterruptedException {
    	UsuarioPage usuarioPage = new UsuarioPage();
		usuarioPage.informarEmail();
    }
    
    @And ("na tela de login informar senha e clicar em entrar")
    public void informarSenha() throws InterruptedException {
    	UsuarioPage usuarioPage = new UsuarioPage();
		usuarioPage.informarSenha();
    }
    
    @Then ("o login eh efetuado com sucesso")
    public void verificarLogin() throws InterruptedException {
    	UsuarioPage usuarioPage = new UsuarioPage();
		usuarioPage.verificarLogin();
    }

}

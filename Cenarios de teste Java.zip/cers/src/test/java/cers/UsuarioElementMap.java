package cers;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class UsuarioElementMap {
	
	@FindBy(xpath = "//*[@id=\"__next\"]/div[1]/header/div[2]/div/div[1]/a/picture/img")
	protected WebElement  logo;
	
	@FindBy(xpath = "//*[@id=\"dropdown-login-register-btn\"]/span[2]")
	protected WebElement bt_login_register;
	
	@FindBy(xpath = "//*[@id=\"dropdown-login-btn\"]")
	protected WebElement bt_login;
	
	@FindBy(xpath = "//*[@id=\"login-email-field\"]")
	protected WebElement campoEmail;
	
	//protected WebElement email;
	
	@FindBy(xpath = "//*[@id=\"login-next-btn\"]")
	protected WebElement bt_prosseguir;
	
	@FindBy(xpath = "//*[@id=\"login-password-field\"]")
	protected WebElement campoSenha;
	
	@FindBy(xpath = "//*[@id=\"login-submit-btn\"]")
	protected WebElement bt_entrar;
	
	//@FindBy(xpath = "//*[@id=\"welcome\"]")
	//protected WebElement welcome;

	protected WebElement welcome;
}

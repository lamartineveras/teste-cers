package cers;

import org.openqa.selenium.support.PageFactory;

/*import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;*/

public class UsuarioPage extends UsuarioElementMap {

	/*public void acessarUrl() {
		// TODO Auto-generated method stub
		logo.equals(logo);
	}*/
	
	public UsuarioPage() {
		PageFactory.initElements(TestRule.getDriver(), this);
	}
	
	public void acessarMenuLogin() throws InterruptedException {
		// TODO Auto-generated method stub
		bt_login_register.click();
		bt_login.click();
		//Thread.sleep(2000);
	}

	public void informarEmail() throws InterruptedException {
		// TODO Auto-generated method stub
		//campoEmail.click();
		//campoEmail.sendKeys("lamartineveras@yahoo.com.br");
		//email.click();
		Thread.sleep(3000);
		campoEmail.sendKeys("lamartineveras@yahoo.com.br");
		Thread.sleep(3000);
		bt_prosseguir.click();
	}

	public void informarSenha() throws InterruptedException {
		// TODO Auto-generated method stub
		//campoSenha.click();
		campoSenha.sendKeys("123456");
		Thread.sleep(3000);
		bt_entrar.click();
		
	}

	public void verificarLogin() throws InterruptedException {
		// TODO Auto-generated method stub
		Thread.sleep(3000);
		welcome.equals(welcome);
		
	}

	
	
	

}
